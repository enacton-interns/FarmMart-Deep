# 7. Epic List

Here is the proposed list of epics to deliver the Farm Market MVP.

*   **Epic 1: Foundation & Farmer Onboarding**
    *   **Goal:** Establish the project's technical foundation, and enable farmers to onboard, become verified, and list their products for customers to browse and search.

*   **Epic 2: Customer Transaction Engine**
    *   **Goal:** Enable customers to create an account, place orders, and pay securely, while providing farmers with the tools to manage incoming orders and basic communication.

***
